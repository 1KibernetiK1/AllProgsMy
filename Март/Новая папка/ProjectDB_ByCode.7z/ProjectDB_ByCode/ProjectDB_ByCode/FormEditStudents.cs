﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectDB_ByCode
{
    public partial class FormEditStudents : Form
    {
        private readonly DataManager _dataManager;
        private DataView _studentsView;
        private DataView _groupsView;

        public FormEditStudents(DataManager dataManager)
        {
            InitializeComponent();
            this._dataManager = dataManager;

            _studentsView = _dataManager
                .GetTableView(EnumTables.Student);

            _groupsView = _dataManager
                .GetTableView(EnumTables.AcademicGroup);

            dataGridView1.DataSource = _studentsView;
            dataGridView1.ReadOnly = true;

            comboBox1.DataSource = _groupsView;
        }
    }
}
