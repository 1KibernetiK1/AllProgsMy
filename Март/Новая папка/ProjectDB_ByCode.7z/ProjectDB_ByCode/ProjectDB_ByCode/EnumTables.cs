﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectDB_ByCode
{
    public enum EnumTables
    {
        AcademicGroup,
        Student
    }
}
