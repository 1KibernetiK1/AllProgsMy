﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectWpf_MVVM.Domains
{
    /// <summary>
    /// Модель объекта предметной области
    /// </summary>
    public class Student
    {
        public string Name { get; set; }

        public int Age { get; set; }
    }
}
