﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_MyOneLinkedList
{
    /* Дз+1
     * добавить метод Remove(position)
     * + добавить свойтсво- количество Count
     * */

    /// <summary>
    /// Коллекция - односвязный список
    /// </summary>
    public class MyOneLinkedList<T>
    {
        // ссылка на "голову" т.е.самый первый элемент
        protected MyNode<T> _head;

        // ссылка на "хвост" т.е.самый последний элемент
        protected MyNode<T> _tail;

        public MyOneLinkedList()
        {
            _head = _tail = null;
        }

        public void Insert(int position, T value)
        {
            MyNode<T> currentNode = _head;
            int counter = 0;
            while(counter < position)
            {
                counter++;
                currentNode = currentNode.Next;
            }
            // вставка
            MyNode<T> node = new MyNode<T>(value);

            node.Next = currentNode.Next;
            currentNode.Next = node;
        }

        public void Add(T value)
        {
            MyNode<T> node = new MyNode<T>(value);

            if (_head == null)
            {
                _head = _tail = node;
                return;
            }

            // новый элемент цепляет в цепочку за хвостом
            _tail.Next = node;
            // теперь этот новый элемент ... 
            // становится хвостом
            _tail = node;
        }
    }
}
