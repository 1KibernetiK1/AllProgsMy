﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectSingletonVacuum
{
    public class AnotherPart
    {
        public void ShowInfo()
        {
            Singleton s3 = Singleton.GetInstance();
            Console.WriteLine(s3.GetName());
        }
    }
}
