﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectSingletonVacuum
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Пример в вакууме");

            // ошибка
            // Singleton s1 = new Singleton();
            Singleton s2 = Singleton.GetInstance();
            s2.SetName("Петя");

            AnotherPart part = new AnotherPart();
            part.ShowInfo();

            Console.ReadLine();
        }
    }
}
