﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectSingletonVacuum
{
    /// <summary>
    /// Паттерн "Одиночка"
    /// </summary>
    public class Singleton
    {
        // могут присутсвовать нестатические / обычные поля и методы
        //----------------------------------------------------------
        // к паттерну не относится
        private string _name;
        public string GetName()
        {
            return _name;
        }
        public void SetName(string name)
        {
            _name = name;
        }
        //----------------------------------------------------------

        // 1) 
        private Singleton()
        {

        }
        // 2) 
        private static Singleton _instance;

        // 3)
        public static Singleton GetInstance()
        {
            if (_instance == null)
            {
                _instance = new Singleton();
            }

            return _instance;
        }
    }
}
