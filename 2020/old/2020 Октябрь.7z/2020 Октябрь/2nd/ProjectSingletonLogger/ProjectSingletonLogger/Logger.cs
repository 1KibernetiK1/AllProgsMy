﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectSingletonLogger
{
    public class Logger
    {
        // могут присутсвовать нестатические / обычные поля и методы
        //----------------------------------------------------------
        // к паттерну не относится
        private StreamWriter _sw;
        private FileStream _fs;

        public void Add(string record)
        {
            DateTime time = DateTime.Now;
            _sw.WriteLine("[{0}] {1}", time, record);
            _sw.Flush(); // принудительная запись сразу на жёсткий диск
        }
        //----------------------------------------------------------

        // 1) 
        private Logger()
        {
            // по хорошему, сущ-й файл нужно копировать в папку
            _fs = new FileStream("app.log", FileMode.Create);

            _sw = new StreamWriter(_fs);

            Add("logger started...");
        }
        // 2) 
        private static Logger _instance;

        // 3)
        public static Logger GetInstance()
        {
            if (_instance == null)
            {
                _instance = new Logger();
            }

            return _instance;
        }
    }
}
