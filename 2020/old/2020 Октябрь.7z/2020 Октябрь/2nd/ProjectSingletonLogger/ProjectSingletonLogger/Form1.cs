﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectSingletonLogger
{
    public partial class Form1 : Form
    {
        private Logger _log = Logger.GetInstance();

        public Form1()
        {
            _log.Add("начинаем инициализацию компонент Form1");
            InitializeComponent();
            _log.Add("инициализированы все компоненты Form1");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _log.Add("user clicked Button1");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            _log.Add("user clicked Button2");
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a = 10;
            int b = 0;
            int c = 0;

            // перехват (обработка) исключений
            try
            {
                c = a / b;
            }
            catch (Exception ex)
            {
                _log.Add("error "+ex.ToString());
                MessageBox.Show("Была перхвачена ошибка, в журнал записана");
            }
        }
    }
}
