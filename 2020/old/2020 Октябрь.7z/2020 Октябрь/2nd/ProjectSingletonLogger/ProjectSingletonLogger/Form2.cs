﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectSingletonLogger
{
    public partial class Form2 : Form
    {
        private Logger _log = Logger.GetInstance();

        public Form2()
        {
            _log.Add("иници компоненты 2-й формы");
            InitializeComponent();
            _log.Add("готово компоненты 2-й формы");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _log.Add("user clicked Form2 Button1");
        }
    }
}
