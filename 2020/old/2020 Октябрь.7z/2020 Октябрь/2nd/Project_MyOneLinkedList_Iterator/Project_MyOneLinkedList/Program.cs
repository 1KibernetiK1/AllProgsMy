﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_MyOneLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            var list = new MyOneLinkedList<int>();
            list.Add(10);
            /*
            list.Add(20);
            list.Add(30);
            list.Add(40);
            list.Add(50);
            list.Add(60);*/

            // вывести все элементы на экран
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }

            // простой цикл
            /*
            for (int i = 0; i < list.Count; i++)
            {
                int number = list[i];
            }*/

            Console.WriteLine("ГОтово");
            Console.ReadLine();
        }
    }
}
