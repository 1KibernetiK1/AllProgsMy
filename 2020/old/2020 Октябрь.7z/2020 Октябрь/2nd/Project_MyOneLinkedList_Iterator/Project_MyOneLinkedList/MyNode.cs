﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_MyOneLinkedList
{
    /// <summary>
    /// Узел в односвязаном списке
    /// (внутри ссылка на следующий +
    /// полезный контент)
    /// </summary>
    public class MyNode<T>
    {
        protected T _content;

        // cсылка !!! класс - это ссылочный тип
        protected MyNode<T> _next;

        public MyNode(T content)
        {
            _content = content;
            _next = null;
        }

        public T Content
        {
            get { return _content; }
            set { _content = value; }
        }

        public MyNode<T> Next
        {
            get { return _next; }
            set { _next = value; }
        }
    }
}
