﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Project03_AsyncAwait
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Async and Await demo:");
            Download();
            while (true)
            {
                Thread.Sleep(300);
                Console.Write(".");
            }
        }

        static async void Download()
        {
            string url = "https://www.microsoft.com";
            var wc = new WebClient();
            var task = wc.DownloadStringTaskAsync(url);

            var res = await task;
            Console.WriteLine("\r\n Получены данные:");
            Console.WriteLine(res.Substring(0, 40));
            Console.WriteLine();
        }
    }
}
