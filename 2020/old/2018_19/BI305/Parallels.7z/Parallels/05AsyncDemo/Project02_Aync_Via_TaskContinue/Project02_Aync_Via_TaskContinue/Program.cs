﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Project02_Aync_Via_TaskContinue
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Async operation Via Task Continue:");
            string url = "https://www.microsoft.com";
            var wc = new WebClient();
            wc
                .DownloadStringTaskAsync(url)
                .ContinueWith(res =>
                {
                    Console.WriteLine("\r\n Получены данные:");
                    Console.WriteLine(res.Result.Substring(0,40));
                    Console.WriteLine();
                });
            while(true)
            {
                Thread.Sleep(300);
                Console.Write(".");
            }
        }
    }
}
