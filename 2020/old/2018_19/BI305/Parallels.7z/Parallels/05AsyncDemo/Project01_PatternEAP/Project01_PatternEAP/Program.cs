﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Project01_PatternEAP
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("EAP = Event-Based Asynchronous");
            string url = "https://www.microsoft.com/";

            var wc = new WebClient();
            wc.DownloadStringCompleted += Wc_DownloadStringCompleted;
            wc.DownloadStringAsync(new Uri(url));

            while(true)
            {
                Thread.Sleep(300);
                Console.Write(".");
            }
        }

        private static void Wc_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            Console.WriteLine("");
            Console.WriteLine("Получены данные от:");
            Console.WriteLine(e.Result.Substring(0, 40));
            Console.WriteLine();
        }
    }
}
