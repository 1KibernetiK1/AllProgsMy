﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using HAP = HtmlAgilityPack;

namespace ProjectRegExp
{
    public partial class Form1 : Form
    {
        List<Concert> list;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string pattern = @"\d";

            if (textBox1.Text != pattern &&
                !string.IsNullOrEmpty(textBox1.Text))
                pattern = textBox1.Text;

            var rx = new Regex(pattern, RegexOptions.None);
            textBox1.Text = pattern;

            string text = textBox2.Text;

            var matches = rx.Matches(text);

            listBox1.Items.Clear();
            // выводим результаты
            foreach (Match m in matches)
            {
                listBox1.Items.Add($"Pos={m.Index} Value={m.Value}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var doc = new HAP.HtmlDocument();

            doc.Load("Primer.html");

            HAP.HtmlNode divContainer = 
                doc
                .DocumentNode
                .SelectSingleNode("//div[@class='container-fluid']");

            var nodes = divContainer
                .ChildNodes
                .Where(d => d.HasClass("row-fluid"))
                .ToList();

            list = new List<Concert>();
            foreach (var n in nodes)
            {
                ParseRowFluid(n);
            }
            list.TrimExcess();
        }

        private void ParseRowFluid(HAP.HtmlNode n)
        {
            var date =
            n.ChildNodes
             .Where(x => x.HasClass("span2"))
             .Select(x => x.InnerText.Trim())
             .Single();

            var description =
            n.ChildNodes
             .Where(x => x.HasClass("span10"))
             .Select(x => x.InnerText.Trim())
             .Single();

            string[] parts = description.Split('\r');

            Concert c;
            string comment = "";

            if (parts.Length > 1)
            {
                comment = parts[1].Trim();
            } else
            {
                comment = "";
            }

            c = new Concert()
            {
                Date = date,
                Title = parts[0].Trim(),
                Comment = comment
            };

            list.Add(c);            
        }
    }
}
